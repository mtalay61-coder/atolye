// SENARYO — EFEKTLERDE BAYAT FONKSİYON (22 Eylül, v1.408.0, denetim 18 C)
//
// İki gerçek hata, ikisi de "efekt, kurulduğu andaki fonksiyonu SONRADAN çağırıyor":
//  1) Stok fişi başlığındaki Kaydet / Ctrl+S: kalemden sonra fiş no ve ödeme şekli değiştirilince
//     fiş ESKİ değerlerle kaydediliyordu (AF-… + Nakit). Beklenen: SONRADAN-NO + Havale/EFT.
//  2) Bekleyen yazmaları yeniden gönderme ("online" olayı / dakikada bir): efekt kurulduğundan
//     beri kesilen fişler yerel depodan SİLİNİYORDU. Beklenen: iki fiş de yerinde.
const { uygulamaAc, depoOku } = require("./ortak.js");
const { TOHUM } = require("./tohum.js");
const { normalles } = require("./senaryo-fis.js");

async function urunEtiketiBul(sayfa, ad) {
  return sayfa.evaluate((a) => { const dl = document.getElementById("fis-urun-listesi");
    const o = dl ? [...dl.options].find((x) => x.value === a || x.value.includes(a)) : null; return o ? o.value : a; }, ad);
}
async function fisKes(sayfa, no, miktar) {
  if (!(await sayfa.locator('[data-cari-fis-ac="Alış"]:visible').count())) {
    await sayfa.getByRole("button", { name: "Cari", exact: true }).click(); await sayfa.waitForTimeout(400);
    await sayfa.locator('button:has-text("Tedarikçi A")').nth(1).click(); await sayfa.waitForTimeout(400);
  }
  await sayfa.locator('[data-cari-fis-ac="Alış"]:visible').first().click(); await sayfa.waitForTimeout(600);
  await sayfa.locator('input[placeholder="Boşsa sistem üretir"]').fill(no);
  await sayfa.locator("[data-urun-arama]").first().fill(await urunEtiketiBul(sayfa, "Deri")); await sayfa.waitForTimeout(300);
  await sayfa.locator("[data-renk-arama]").first().fill("Siyah"); await sayfa.waitForTimeout(300);
  await sayfa.locator("[data-kalem-fiyat]:visible").first().fill("150");
  await sayfa.locator("[data-kalem-miktar]:visible").first().fill(String(miktar));
  await sayfa.locator("[data-kalemlere-ekle]:visible").first().click(); await sayfa.waitForTimeout(400);
  await sayfa.locator("[data-fis-kaydet]").first().click(); await sayfa.waitForTimeout(1500);
}

async function calistir() {
  const sonuc = {};
  {
  const { tarayici, sayfa } = await uygulamaAc(TOHUM, { hataYaz: false });
  await sayfa.waitForTimeout(2200);
  await sayfa.getByRole("button", { name: "Cari", exact: true }).click(); await sayfa.waitForTimeout(400);
  await sayfa.locator('button:has-text("Tedarikçi A")').nth(1).click(); await sayfa.waitForTimeout(400);
  await sayfa.locator('[data-cari-fis-ac="Alış"]').first().click(); await sayfa.waitForTimeout(600);
  await sayfa.locator("[data-urun-arama]").first().fill(await urunEtiketiBul(sayfa, "Deri")); await sayfa.waitForTimeout(300);
  await sayfa.locator("[data-renk-arama]").first().fill("Siyah"); await sayfa.waitForTimeout(300);
  await sayfa.locator("[data-kalem-fiyat]:visible").first().fill("150");
  await sayfa.locator("[data-kalem-miktar]:visible").first().fill("3");
  await sayfa.locator("[data-kalemlere-ekle]:visible").first().click(); await sayfa.waitForTimeout(400);
  // KALEMDEN SONRA: fiş no ve ödeme şekli
  await sayfa.locator('input[placeholder="Boşsa sistem üretir"]').fill("SONRADAN-NO");
  const yeniOdeme = "Havale/EFT";
  await sayfa.locator('select:has(option:text-is("Havale/EFT")):visible').first().selectOption(yeniOdeme);
  await sayfa.waitForTimeout(300);
  await sayfa.locator('input[placeholder="Boşsa sistem üretir"]').focus();
  await sayfa.keyboard.press("Control+s"); await sayfa.waitForTimeout(1500);
  const deri = (await depoOku(sayfa, "stok:items")).find((p) => p.ad === "Deri");
  const son = (deri.hareketler || []).filter((h) => h.miktar === 3);
  const cari = (await depoOku(sayfa, "cari:data")).find((c) => c.unvan === "Tedarikçi A");
  sonuc.baslikKaydet = ({ beklenenOdeme: yeniOdeme,
    stokFisNo: son.map((h) => h.fisNo), cariHareket: (cari.hareketler || []).slice(-1).map((h) => ({ fisNo: h.fisNo, odeme: h.odemeSekli })) });
  await tarayici.close();

  }
  {
  const { tarayici: t2, sayfa: s2 } = await uygulamaAc(TOHUM, { hataYaz: false });
  await s2.waitForTimeout(3000);
  await fisKes(s2, "BIR", 3);
  await fisKes(s2, "IKI", 5);
  const fisler = async () => ((await depoOku(s2, "stok:items")).find((p) => p.ad === "Deri").hareketler || [])
    .map((h) => h.fisNo).filter((f) => f === "BIR" || f === "IKI");
  const once = await fisler();
  await s2.evaluate(() => window.dispatchEvent(new Event("online")));
  await s2.waitForTimeout(2500);
  sonuc.baglantiGelince = ({ onlineOncesi: once, onlineSonrasi: await fisler() });
  await t2.close();
  }
  return sonuc;
}

if (require.main === module) {
  calistir().then((s) => console.log(normalles(s)));
}

module.exports = { calistir };
