// SENARYO — Alış siparişinden TESLİM ALMA (`siparisGerceklestir` yolu).
// Kullanımı senaryo-fis.js ile aynı: çalıştır, çıktıyı refaktör öncesi/sonrası karşılaştır.
const { uygulamaAc, depoOku } = require("./ortak.js");
const { TOHUM } = require("./tohum.js");
const { normalles } = require("./senaryo-fis.js");

async function calistir() {
  const { tarayici, sayfa } = await uygulamaAc(TOHUM, { hataYaz: false });
  const hatalar = [];
  sayfa.on("pageerror", (e) => hatalar.push(e.message.split("\n")[0]));
  await sayfa.waitForTimeout(2000);

  await sayfa.getByRole("button", { name: "Alış Siparişi", exact: true }).click();
  await sayfa.waitForTimeout(400);
  await sayfa.locator("[data-durum-cip=\"Tümü\"]:visible").first().click();
  await sayfa.waitForTimeout(400);
  // Önce özet satırı açılır, sonra kartın kendisi tam ekrana alınır: teslim paneli yalnızca
  // tam karttadır (özet satırı salt okunur önizlemedir).
  await sayfa.locator('div:has-text("AS-1")').last().click();
  await sayfa.waitForTimeout(500);
  await sayfa.locator('button[title^="Tam ekran aç"]:visible').first().click();
  await sayfa.waitForTimeout(600);

  await sayfa.locator("[data-fis-olustur]:visible").first().click();
  await sayfa.waitForTimeout(600);

  // KISMİ teslim: 6 sipariş edilmişti, 4 alınıyor — "Kısmi Teslim" durumu ve karşılanan güncellemesi
  // de kapsama girsin.
  // İki kalem var: ilkinden 4 (kısmi), ikincisinden 3 (tam) alınıyor.
  // KALEM = MODEL + RENK (v1.55.0): beden seçilmiyor. Renk eklenince o rengin bütün bedenleri
  // satırda listelenir ve siparişteki kalan miktarlarla DOLU gelir; sonra elle düzeltilir.
  await sayfa.locator('button:has-text("Kalem Ekle")').last().click();
  await sayfa.waitForTimeout(500);
  await sayfa.locator('input[title^="Çıkılacak miktar"]:visible').first().fill("4");
  await sayfa.locator('select:has(option:text-is("Bot"))').first().selectOption({ label: "Bot" });
  await sayfa.waitForTimeout(400);
  await sayfa.locator('button:has-text("Kalem Ekle")').last().click();
  await sayfa.waitForTimeout(500);
  const botKutusu = sayfa.locator('input[title^="Çıkılacak miktar"]:visible').last();
  await botKutusu.fill("3");
  await sayfa.waitForTimeout(300);
  await sayfa.locator("[data-islem-kaydet]:visible").first().click();
  await sayfa.waitForTimeout(500);
  // İkinci adım: uygulama stok etkisini özetleyip onay istiyor.
  await sayfa.locator("[data-onay-evet]:visible").first().click();
  await sayfa.waitForTimeout(1500);

  const stok = await depoOku(sayfa, "stok:items");
  const cariler = await depoOku(sayfa, "cari:data");
  const siparisler = await depoOku(sayfa, "siparis:data");
  await tarayici.close();

  return {
    hatalar,
    stok: (stok || []).map((p) => ({ ad: p.ad, variants: p.variants, hareketler: p.hareketler })),
    cariler: (cariler || []).map((c) => ({ unvan: c.unvan, hareketler: c.hareketler })),
    siparisler: (siparisler || []).map((s) => ({ no: s.siparisNo, durum: s.durum, teslimSayaci: s.teslimSayaci, defterTercihi: s.defterTercihi, kalemler: s.kalemler })),
  };
}

if (require.main === module) {
  calistir().then((s) => {
    if (s.hatalar.length) console.log("SAYFA HATASI:", s.hatalar.join(" | "));
    console.log(normalles(s));
  });
}

module.exports = { calistir };
