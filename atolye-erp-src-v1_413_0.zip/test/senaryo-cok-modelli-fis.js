// SENARYO — ÜÇ MODELLİ SİPARİŞTE İKİSİNİ TEK FİŞTE SATMA.
//
// Kullanıcının sorusu: "1 siparişimiz var, içinde 3 ayrı model satır var. 3 modelin 2'si için tek
// fişte satış yapmak istiyorum: SAT-1001-F1 içinde 2 model."
//
// Ölçülen: iki model "Kalem Ekle" ile ayrı satır olarak ekleniyor, kaydedince İKİSİ DE AYNI fiş
// numarasına yazılıyor ve üçüncü model fişin dışında kalıp siparişte bekliyor.
const { uygulamaAc, depoOku } = require("./ortak.js");
const { TOHUM } = require("./tohum.js");
const { normalles } = require("./senaryo-fis.js");

async function calistir() {
  const t = { ...TOHUM };
  const stok = JSON.parse(t["stok:items"]);
  // Üç ayrı MAMUL model, hepsinde stok var (satış yapılabilsin)
  stok.push(
    { id: "m1", ad: "125 Model", kategori: "Mamul", birim: "çift", olcuTipi: "Beden",
      variants: [{ renk: "Bej", beden: "40", miktar: 50 }, { renk: "Bej", beden: "41", miktar: 50 }],
      hareketler: [], recete: [], birimFiyat: 465 },
    { id: "m2", ad: "SS Model", kategori: "Mamul", birim: "çift", olcuTipi: "Beden",
      variants: [{ renk: "Beyaz", beden: "40", miktar: 50 }, { renk: "Beyaz", beden: "41", miktar: 50 }],
      hareketler: [], recete: [], birimFiyat: 520 },
    { id: "m3", ad: "300 Model", kategori: "Mamul", birim: "çift", olcuTipi: "Beden",
      variants: [{ renk: "Siyah", beden: "40", miktar: 50 }], hareketler: [], recete: [], birimFiyat: 600 },
  );
  t["stok:items"] = JSON.stringify(stok);
  t["siparis:data"] = JSON.stringify([{
    id: "s9", siparisNo: "SAT-1001", tip: "Satış", cariId: "c2", durum: "Onaylandı",
    tarih: "2026-08-25", teslimTarihi: "2026-09-10", teslimSayaci: 0,
    kalemler: [
      { id: "k1", urunId: "m1", urunAd: "125 Model", renk: "Bej", beden: "40", miktar: 10, karsilanan: 0, birim: "çift", birimFiyat: 465, paraBirimi: "TRY" },
      { id: "k2", urunId: "m1", urunAd: "125 Model", renk: "Bej", beden: "41", miktar: 10, karsilanan: 0, birim: "çift", birimFiyat: 465, paraBirimi: "TRY" },
      { id: "k3", urunId: "m2", urunAd: "SS Model", renk: "Beyaz", beden: "40", miktar: 8, karsilanan: 0, birim: "çift", birimFiyat: 520, paraBirimi: "TRY" },
      { id: "k4", urunId: "m2", urunAd: "SS Model", renk: "Beyaz", beden: "41", miktar: 8, karsilanan: 0, birim: "çift", birimFiyat: 520, paraBirimi: "TRY" },
      { id: "k5", urunId: "m3", urunAd: "300 Model", renk: "Siyah", beden: "40", miktar: 5, karsilanan: 0, birim: "çift", birimFiyat: 600, paraBirimi: "TRY" },
    ],
  }]);

  const { tarayici, sayfa } = await uygulamaAc(t, { hataYaz: false });
  const hatalar = []; sayfa.on("pageerror", (e) => hatalar.push(e.message.split("\n")[0]));
  await sayfa.waitForTimeout(2200);
  await sayfa.getByRole("button", { name: "Sipariş", exact: true }).click();
  await sayfa.waitForTimeout(500);
  await sayfa.locator("[data-durum-cip=\"Tümü\"]:visible").first().click();
  await sayfa.waitForTimeout(400);
  await sayfa.evaluate(() => {
    const el = [...document.querySelectorAll("*")].find((e) =>
      e.getBoundingClientRect().width > 0 && (e.textContent || "").trim() === "SAT-1001" && e.children.length === 0);
    let p = el; for (let i = 0; i < 8 && p; i++, p = p.parentElement) { if (p.onclick || p.tagName === "BUTTON") { p.click(); return; } }
  });
  await sayfa.waitForTimeout(500);
  await sayfa.locator('button[title^="Tam ekran aç"]:visible').first().click();
  await sayfa.waitForTimeout(600);
  await sayfa.locator("[data-fis-olustur]:visible").first().click();
  await sayfa.waitForTimeout(700);

  // 1. model: 125 Model (varsayılan seçili)
  await sayfa.locator("[data-grup-ekle]:visible").first().click();
  await sayfa.waitForTimeout(400);
  // 2. model: SS Model. Seçim ekledikten sonra kendiliğinden sonraki kombinasyona kaydığı için
  // (v1.58.0) listeden seçmeye gerek kalmadan doğrudan tekrar basmak yeterli — ama senaryo yine
  // de açıkça seçiyor ki iki yol da sınansın.
  await sayfa.locator('select:has(option:text-is("SS Model")):visible').first().selectOption({ label: "SS Model" });
  await sayfa.waitForTimeout(300);
  await sayfa.locator("[data-grup-ekle]:visible").first().click();
  await sayfa.waitForTimeout(400);
  // 300 Model EKLENMİYOR — üçüncüsü bu fişin dışında kalmalı
  const dugmeMetni = ((await sayfa.locator('button:has-text("Kalem Ekle"):visible, button:has-text("Zaten eklendi"):visible').first().textContent()) || "").trim();
  const satirSayisi = await sayfa.locator('button[title="Bu satırı çıkar"]:visible').count();
  const bedenKutusu = await sayfa.locator('input[title^="Çıkılacak miktar"]:visible').count();

  await sayfa.locator("[data-islem-kaydet]:visible").first().click();
  await sayfa.waitForTimeout(500);
  await sayfa.locator("[data-onay-evet]:visible").first().click();
  await sayfa.waitForTimeout(1600);

  const cariler = await depoOku(sayfa, "cari:data");
  const musteri = cariler.find((c) => c.id === "c2");
  const gruplar = {};
  (musteri.hareketler || []).forEach((h) => {
    gruplar[h.fisNo] = gruplar[h.fisNo] || [];
    gruplar[h.fisNo].push(`${h.urunAd} ${h.renk} ${h.beden} ×${h.miktar}`);
  });
  const sip = await depoOku(sayfa, "siparis:data");
  await tarayici.close();

  return {
    hatalar,
    satirSayisi,
    bedenKutusu,
    fisler: gruplar,
    karsilanan: sip[0].kalemler.map((k) => `${k.urunAd} ${k.beden}: ${k.karsilanan}/${k.miktar}`),
    // Düğme metni: eklenmemiş kombinasyon kalmayınca kilitlenip durumu söylemeli.
    ucuncuModelEklenmedenOnceDugme: dugmeMetni,
    durum: sip[0].durum,
  };
}

if (require.main === module) {
  calistir().then((s) => {
    if (s.hatalar.length) console.log("SAYFA HATASI:", s.hatalar.join(" | "));
    console.log(normalles(s));
  });
}

module.exports = { calistir };
