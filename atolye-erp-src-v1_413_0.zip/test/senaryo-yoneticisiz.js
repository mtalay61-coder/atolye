// SENARYO — YÖNETİCİSİZ LİSTE KİLİDİ (kullanıcı, 13 Eylül: sıfırlama sonrası "Kullanıcı" rolüyle
// eklenen tek kullanıcıyla giriş açıldı, kısıtlı girdi, Tanımlar'a giremediği için düzeltemedi).
// Ölçülen: 1) listede yönetici yokken eklenen ilk kullanıcı Yönetici olur; 2) yöneticisiz listeyle
// giriş açılamaz; 3) yine de yöneticisiz listeyle giriş yapılmışsa giren kişi Yönetici yapılır.
const { uygulamaAc, depoOku } = require("./ortak.js");
const { TOHUM } = require("./tohum.js");
const { normalles } = require("./senaryo-fis.js");

async function calistir() {
  const t = { ...TOHUM };
  const tanimlar = JSON.parse(TOHUM["tanimlar:data"]);
  // Eski veriden kalmış hâl: tek kullanıcı "Kullanıcı" rolünde, giriş açık.
  t["tanimlar:data"] = JSON.stringify({ ...tanimlar, girisAktifMi: true,
    kullanicilar: [{ id: "k1", ad: "Ali", kullaniciAdi: "ali", sifre: "gizli123", rol: "Kullanıcı", yetkiler: {} }] });
  const { tarayici, sayfa } = await uygulamaAc(t, { hataYaz: false });
  const hatalar = []; sayfa.on("pageerror", (e) => hatalar.push(e.message.split("\n")[0]));
  await sayfa.route("**/auth/v1/token**", (route) => route.fulfill({ status: 400, contentType: "application/json", body: JSON.stringify({ error_description: "Invalid login credentials" }) }));
  await sayfa.waitForTimeout(2500);
  await sayfa.locator('input:not([type="password"])').first().fill("ali");
  await sayfa.locator('input[type="password"]').first().fill("gizli123");
  await sayfa.getByRole("button", { name: "Giriş Yap" }).click();
  await sayfa.waitForTimeout(1800);
  const girisSonrasi = {
    rol: ((await depoOku(sayfa, "tanimlar:data")).kullanicilar || [])[0].rol,
    tanimlarMenude: await sayfa.evaluate(() => [...document.querySelectorAll("button")].some((b) => /Tanımlar/.test(b.textContent) && b.getBoundingClientRect().width > 0)),
  };

  // Yeni veritabanı: kullanıcı yok, giriş pasif → Tanımlar'dan "Kullanıcı" rolüyle ekle → Yönetici olmalı;
  // yöneticisiz listeyle giriş açılamamalı.
  const t2 = { ...TOHUM };
  t2["tanimlar:data"] = JSON.stringify({ ...tanimlar, girisAktifMi: false, kullanicilar: [] });
  const ikinci = await uygulamaAc(t2, { hataYaz: false });
  const s2 = ikinci.sayfa;
  s2.on("pageerror", (e) => hatalar.push(e.message.split("\n")[0]));
  s2.on("dialog", (d) => d.accept());
  await s2.route("**/functions/v1/kullanici", (route) => route.fulfill({ status: 404, body: "{}" }));
  await s2.waitForTimeout(2500);
  await s2.getByRole("button", { name: "Tanımlar / Ayarlar", exact: true }).first().click();
  await s2.waitForTimeout(600);
  await s2.evaluate(() => { const b = [...document.querySelectorAll("button")].find((x) => x.textContent.trim() === "Kullanıcılar" && x.getBoundingClientRect().width > 0); if (b) b.click(); });
  await s2.waitForTimeout(400);
  // Giriş yöneticisiz açılamaz (henüz kullanıcı yok).
  await s2.evaluate(() => { const b = [...document.querySelectorAll("button")].find((x) => x.textContent.trim() === "Aktif" && x.getBoundingClientRect().width > 0); if (b) b.click(); });
  await s2.waitForTimeout(500);
  const girisAcilmadi = !((await depoOku(s2, "tanimlar:data")).girisAktifMi);
  await s2.locator('input[placeholder="Ad Soyad"]').fill("Veli");
  await s2.locator('input[placeholder="Kullanıcı adı"]').fill("veli");
  await s2.locator('input[placeholder="Şifre"]').fill("sifre123");
  await s2.evaluate(() => { const b = document.querySelector("[data-kullanici-ekle]"); if (b) b.click(); });
  await s2.waitForTimeout(1200);
  const ilkKullanici = ((await depoOku(s2, "tanimlar:data")).kullanicilar || []).map((k) => `${k.ad}:${k.rol}`);
  await ikinci.tarayici.close();
  await tarayici.close();
  return { hatalar, girisSonrasi, girisAcilmadi, ilkKullanici };
}

if (require.main === module) {
  calistir().then((s) => console.log(normalles(s)));
}

module.exports = { calistir };
